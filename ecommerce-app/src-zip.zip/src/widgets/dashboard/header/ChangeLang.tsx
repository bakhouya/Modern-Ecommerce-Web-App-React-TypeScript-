import { useTranslation } from 'react-i18next';

function LanguageSwitcher() {
  const { i18n } = useTranslation();

  const changeLanguage = (lng: string | undefined) => {
    i18n.changeLanguage(lng);
    document.documentElement.dir = lng === 'ar' ? 'rtl' : 'ltr';
  };

  return (
    <div className='flex_start_center gap_10'>
      <button 
          className={`btn_icon sm border ${i18n.language === 'en' ? "bg_2_primary" : ""}`} 
          onClick={() => changeLanguage('en')}>
          En
      </button>
      <button 
          className={`btn_icon sm border ${i18n.language === 'fr' ? "bg_2_primary" : ""}`} 
          onClick={() => changeLanguage('fr')}>
            Fr
      </button>
      <button 
        className={`btn_icon sm border ${i18n.language === 'ar' ? "bg_2_primary" : ""}`} 
        onClick={() => changeLanguage('ar')}>
          Ar
      </button>
    </div>
  );
}

export default LanguageSwitcher;