




import { useEffect, useRef, useState } from "react";
import WEBROUTES from "../../../routers/web/path";
import { LogIn, UserPlus, Package, CircleHelp, ShieldCheck} from "lucide-react";
import { Link } from "react-router-dom";
import user from "../../../assets/svg/user.svg";

const AccountMenu = () => {
    const [isOpen, setIsOpen] = useState(false);
    const menuRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (menuRef.current && !menuRef.current.contains(event.target as Node)) {setIsOpen(false);}
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => {document.removeEventListener("mousedown", handleClickOutside);};
    }, []);

    return (
        <div className="account-menu" ref={menuRef}>

            <button className="action action--icon text_center" onClick={() => setIsOpen((prev) => !prev)}>
                <img src={user} alt="" width="24" loading="lazy" className="mx_auto"/>
                <div className="text text_sm">
                    Mon compte
                </div>
            </button>

            {isOpen && (
                <div className="account-menu__dropdown">

                    <Link to="/login" className="account-menu__item">
                        <LogIn size={18} />
                        <div className="text text_sm">Se connecter</div>
                    </Link>

                    <Link to="/register" className="account-menu__item">
                        <UserPlus size={18} />
                        <div className="text text_sm">Créer un compte</div>
                    </Link>

                    <div className="account-menu__divider" />

                    <Link to={WEBROUTES.TRACKORDER} className="account-menu__item">
                        <Package size={18} />
                        <div className="text text_sm">Suivre mes commandes</div>
                    </Link>

                    <Link to="/help" className="account-menu__item">
                        <CircleHelp size={18} />
                        <div className="text text_sm"> Aide </div>
                    </Link>

                    <Link to="/terms" className="account-menu__item">
                        <ShieldCheck size={18} />
                        <div className="text text_sm">Conditions d'utilisation</div>
                    </Link>

                </div>
            )}
        </div>
    );
};

export default AccountMenu;