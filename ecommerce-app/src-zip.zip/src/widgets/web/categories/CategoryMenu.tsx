

import {ChevronRight, Menu, X} from "lucide-react";
import type { CategoryTypesParents } from "../../../types/categoryTypes";
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import MenuSvg from "../../../assets/svg/menu.svg"
import WEBROUTES from "../../../routers/web/path";

interface CategoryMenuProps {categories: CategoryTypesParents[]; screenPhone: boolean}

const CategoryMenu = ({ categories, screenPhone }: CategoryMenuProps) => {

    const [isOpen, setIsOpen] = useState(false);
    const [activeCategory, setActiveCategory] = useState<CategoryTypesParents | null>(null);
    const categoryMenuRef = useRef<HTMLDivElement>(null);


    useEffect(() => {
        const handleClickOutside = (event: MouseEvent) => {
            if (
                categoryMenuRef.current &&
                !categoryMenuRef.current.contains(event.target as Node)
            ) {
                setIsOpen(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);

        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, []);

    const Onclose = () =>  {
        setIsOpen(false) 
        setActiveCategory(null)
    } 

    return (

        <div className="category_menu" ref={categoryMenuRef}>  
            {screenPhone ? 
                <button type="button" className="mobile-bottom-nav__item" onMouseDown={() => setIsOpen(true) }>
                    <Menu size={21} />
                    <span>Menu</span>
                </button>
            :
                <button className="category_button hover" onMouseDown={() => setIsOpen(true) }>
                    <img src={MenuSvg} alt="" width={"25"} loading="lazy" className="mx_auto"/>
                </button>
            }        
            {isOpen && (
                <div className="overlay_menu">
                    <div className="category_dropdown">

                        <div className="category_dropdown__parents">
                            <div className="children_header flex_between_center">
                                <div className="text text_xl"> Catalog Menu </div>
                                <button className="btn_icon md" onClick={Onclose}>
                                    <X/>
                                </button>
                            </div>

                            {categories?.map((category) => (
                                <div key={category.id} className="category_item flex_between_center" onClick={() => setActiveCategory(category)}>
                                    <div className="flex_start_center gap_12">
                                        <img src={category.image} alt="" loading="lazy" width="20"/>
                                        <span className="text text_sm"> {category.title} </span>
                                    </div>
                                    {category.children?.length > 0 && ( <ChevronRight size={16} /> )}
                                </div>
                            ))}

                        </div>

                        {activeCategory &&
                            activeCategory.children?.length > 0 && (
                                <div className="category_dropdown__children">

                                    <div className="children_header">
                                        <div className="text text_xl"> {activeCategory.title} </div>
                                    </div>

                                    <div className="children_list">
                                    {activeCategory.children.filter((child) => child.status).map((child) => (
                                        <Link to={WEBROUTES.CATEGORY(child.id)} key={child.id} className="child_category" onClick={Onclose}>
                                            <div className="text text_center text_sm"> {child.title} </div>
                                        </Link>
                                    ))}
                                    </div>

                                </div>
                            )}

                    </div>
                </div>
            )}
        </div>

    );

};

export default CategoryMenu;