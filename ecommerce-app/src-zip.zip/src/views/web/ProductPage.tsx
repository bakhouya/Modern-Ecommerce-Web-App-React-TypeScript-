import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { useHomePageProducts, useProduct, useProductOffers } from "../../controllers/usePublicProducts";
import type { IProductImage, ValueDetail, VariantDetail } from "../../types/productTypes";
import { useAddToCart } from "../../controllers/useCart";
import { LoadingDisplay } from "../../components/ui/LoadingDisplay";
import ProductCard from "../../widgets/web/products/ProductCard";
import { NotFound } from "../../components/ui/NoutFound";
import ImagePlaceholder from '../../assets/images/placeholder_product.png' ;

export default function ProductPage() {
    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const { id } = useParams<{ id: string }>();
    /* --------------------------------------------------------------------------------------------------- */

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const { data: product, isLoading, isError } = useProduct(id);
    const { data: products } = useHomePageProducts();
    const { data: offer } = useProductOffers(id);
    const addToCartMutation = useAddToCart();
    /* --------------------------------------------------------------------------------------------------- */

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const [selectedImage, setSelectedImage] = useState(0);
    const [selectedValues, setSelectedValues] = useState<Record<string, string>>({});
    const [quantity, setQuantity] = useState(1);
    const [activeTab, setActiveTab] = useState<"description" | "details">("description");
    useEffect(() => {window.scrollTo({top: 0, behavior: "instant"});}, []);
    /* --------------------------------------------------------------------------------------------------- */

    

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const attributes = useMemo(() => {
        if (!product?.variants_details) return {};

        const result: Record<string,{title: string; type: string; values: string[];}> = {};

        product.variants_details.forEach((variant: VariantDetail) => {
        variant.values_details?.forEach((item: ValueDetail) => {
            if (!result[item.attribute_title]) {
            result[item.attribute_title] = {
                title: item.attribute_title,
                type: item.type,
                values: [],
            };
            }

            if (!result[item.attribute_title].values.includes(item.value)) {
            result[item.attribute_title].values.push(item.value);
            }
        });
        });

        return result;
    }, [product]);
    /* --------------------------------------------------------------------------------------------------- */



    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const selectedVariant = useMemo(() => {
        if (!product?.variants_details?.length) {return null;}

        // Product has no selectable attributes.
        // Use the default variant from database.
        if (Object.keys(attributes).length === 0) {
            return (product.variants_details.find((variant: VariantDetail) => variant.is_default) ?? null);
        }
        // Product has selectable attributes.
        // User must select all attributes.
        const allAttributesSelected = Object.keys(attributes).every((attribute) => Boolean(selectedValues[attribute]));

        if (!allAttributesSelected) {return null;}

        // Find the exact variant matching selected values.
        return (
            product.variants_details.find((variant: VariantDetail) =>
            variant.values_details.every(
                (item: ValueDetail) =>
                selectedValues[item.attribute_title] === item.value
            )
            ) ?? null
        );
    }, [product, attributes, selectedValues]);
    /* --------------------------------------------------------------------------------------------------- */

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const handleSelect = (attribute: string, value: string) => {
        setSelectedValues((prev) => ({...prev, [attribute]: value, }));
        setQuantity(1);
    };
    /* --------------------------------------------------------------------------------------------------- */

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    if (isLoading) {return (<section className="product-page"> <LoadingDisplay /> </section>);}
    if (isError || !product) {return (<NotFound/>);}
    /* --------------------------------------------------------------------------------------------------- */

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const renderProductText = (text: string) => {
        return text.split(/\n\s*\n/).map((paragraph, index) => {
            const lines = paragraph
            .split("\n")
            .map((line) => line.trim())
            .filter(Boolean);

            const isList = lines.every((line) => line.startsWith("-"));

            if (isList) {
            return (
                <ul key={index} className="product-tabs__list">
                {lines.map((line, lineIndex) => (<li key={lineIndex}> {line.replace(/^-\s*/, "")}</li>))}
                </ul>
            );
            }

            return (
                <p key={index} className="product-tabs__paragraph">
                    {lines.map((line, lineIndex) => (
                    <span key={lineIndex}>
                        {line}
                        {lineIndex < lines.length - 1 && <br />}
                    </span>
                    ))}
                </p>
            );
        });
    };
    /* --------------------------------------------------------------------------------------------------- */

    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const images = product.images_details ?? [];
    const currentPrice = Number( selectedVariant?.price ?? product.price_sale ?? product.price_regular) * quantity;
    const currentStock = selectedVariant?.total_stock  ?? 0;
    const isAddToCartDisabled = !selectedVariant || selectedVariant.total_stock  <= 0;
    /* --------------------------------------------------------------------------------------------------- */


    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    const handleAddToCart = () => {
        if (!selectedVariant) {return;}
        const payload = {variant: selectedVariant.id, quantity};
        addToCartMutation.mutate(payload, {onSuccess: () => {console.log("added sucessfuly")},});
    };
    /* --------------------------------------------------------------------------------------------------- */



    /* --------------------------------------------------------------------------------------------------- */
    /* --------------------------------------------------------------------------------------------------- */
    return (
        <section className="product-page">

            <div className="product-page__container web_container">

                <div className="product-gallery">
                <div className="product-gallery__main">
                    <img src={images[selectedImage]?.image || ImagePlaceholder} alt={product.title}/>
                </div>

                {images.length > 1 && (
                    <div className="product-gallery__thumbnails">
                    {images.map((image: IProductImage, index: number) => (
                        <button
                        key={image.id}
                        type="button"
                        className={selectedImage === index ? "product-gallery__thumbnail active": "product-gallery__thumbnail"}
                        onClick={() => setSelectedImage(index)}
                        >
                        <img src={image.image} alt={`${product.title} ${index + 1}`} />
                        </button>
                    ))}
                    </div>
                )}
                </div>

                <div className="product-info">

                    <div className="text text_sm my_start_8">{product.title}</div>

                    <div className="product-info__rating text text_sm">
                        <span>★</span>
                        <span>{product.rating || "No rating"}</span>
                        <span className="separator">•</span>
                        <span>{product.comments} reviews</span>
                    </div>
                
                    <div className="flex_start_center gap_10 my_start_8">
                        <div className="Ttext text_xl text_primary">
                            {Number(currentPrice).toFixed(2)} MAD
                        </div>
                        {product.price_regular &&
                            Number(product.price_regular) * quantity > Number(currentPrice) && (
                            <div className="text text_sm regular_price">
                                {/* {Number(product.price_regular).toFixed(2)} MAD */}
                                {Number(product.price_regular) * quantity} MAD
                            </div>
                        )}
                        <div className=""></div>
                        <div className="text text_xs descouver_info text_primary"> 50% DE RÉDUCTION Durée limitée </div>
                    </div>
                
                    <div className="product-info__stock">
                        {currentStock > 0 ? (
                            <span className="in-stock"> In stock ({currentStock}) </span>
                        ) : (
                            <span className="out-stock"> 
                                Cette sélection est momentanément indisponible. Nous vous invitons à choisir une autre option pour poursuivre votre commande.
                            </span>
                        )}
                    </div>

                    <div className="product-info__divider" />

                    <div className="product-variants">
                        {Object.entries(attributes).map(
                            ([attribute, config]) => (
                                <div className="product-variant" key={attribute}>
                                    <div className="text text_md flex_between_center">
                                        <span className="my_end_8">{config.title}</span>
                                        {/* <div className="text text_sm"> {selectedValues[attribute] && (<strong>{selectedValues[attribute]}</strong>)} </div>    */}
                                        <div className="text text_sm"> 
                                            {selectedValues[attribute] 
                                                ? (<strong>{selectedValues[attribute]}</strong>) 
                                                : (<strong> --- </strong>)}  
                                        </div>   
                                    </div>

                                    <div className={config.type === "color" ? "product-variant__options product-variant__options--colors" : "product-variant__options"}>
                                        {config.values.map((value) => {
                                            const isSelected = selectedValues[attribute] === value;
                                            return (
                                                <button key={value} type="button" className={isSelected ? "variant-option selected" : "variant-option"}
                                                onClick={() =>handleSelect(attribute, value)}>
                                                {config.type === "color" && (
                                                    <span
                                                    className="variant-option__color"
                                                    // style={{
                                                    //     backgroundColor: value.toLowerCase() === "noir" ? "#111" : value.toLowerCase() === "bleu" ? "#2563eb" : value,
                                                    // }}/>
                                                    style={{backgroundColor: value.toLowerCase()}} />
                                                )}
                                                <div className="text text_sm"> {value} </div>
                                                </button>
                                            );
                                        })}
                                    </div>
                                </div>
                            )
                        )}
                    </div>

                    <div className="product-quantity">
                        <div className="text text_md">Quantité </div>

                        <div className="product-quantity__control">
                            <button type="button" onClick={() => setQuantity((prev) => Math.max(1, prev - 1))} disabled={quantity <= 1} aria-label="Diminuer la quantité">
                                −
                            </button>

                            <span>{quantity}</span>

                            <button type="button"
                                onClick={() =>
                                    setQuantity((prev) => Math.min(currentStock, prev + 1))
                                } disabled={quantity >= currentStock} aria-label="Augmenter la quantité">
                                +
                            </button>
                        </div>
                    </div>

                    <div className="product-info__divider" />


                    <button
                        type="button"
                        className="btn primary xl radius_30"
                        disabled={isAddToCartDisabled || addToCartMutation.isPending}
                        onClick={handleAddToCart}>
         
                        {addToCartMutation.isPending && (<div className="btn_loader"></div>)}
                        <div className="text text_sm text_white weight_600">
                            {addToCartMutation.isPending ? "Ajouter..." : "Ajouter au Panier"}
                        </div>
                    </button>

                    {offer && (
                        <div className="product-offers my_start_10">
                            <div className="">
                                
                                {offer.condition_type === "QUANTITY" &&
                                    offer.variants?.length > 0 && (
                                    <div className="">
                                        {offer.variants.map((variant, index) => (
                                            <div className={`product-offer ${quantity >= variant.min_order_pieces ? "active" : ""}`} key={index}>
                                                <div className="text text_sm">
                                                    À partir de <span>{variant.min_order_pieces}</span> pièces
                                                </div>

                                                <div className="text text_sm">
                                                    {quantity >= variant.min_order_pieces
                                                    ? "Vous bénéficiez de cette offre."
                                                    : `Ajoutez encore ${variant.min_order_pieces - quantity} pièce(s) pour en bénéficier.`}
                                                </div>

                                                {variant.discount_percentage !== null && (
                                                    <div className="text text_sm text_primary">-{variant.discount_percentage}%</div>
                                                )}

                                                {variant.discount_fixed_amount !== null && (
                                                    <div className="text text_sm text_primary">-{variant.discount_fixed_amount} MAD</div>
                                                )}
                                                </div>

                                        ))}
                                    </div>
                                )}

                                {offer.condition_type !== "QUANTITY" && (
                                    <div className="product-offer__discount">
                                        {offer.discount_percentage !== null && (
                                            <span> Réduction de{" "} <strong> {offer.discount_percentage}% </strong></span>
                                        )}

                                        {offer.discount_fixed_amount !== null && (
                                            <span> Réduction de{" "} <strong> {offer.discount_fixed_amount} MAD</strong></span>
                                        )}

                                        {offer.min_order_price !== null && (
                                            <span> À partir de{" "} <strong> {offer.min_order_price} MAD </strong> </span>
                                        )}
                                    </div>
                                )}
                            </div>
                        </div>
                    )}


                </div>

            </div>


            <div className="web_container product_page_bottom">
                <section className="product-tabs">

                    <div className="product-tabs__nav">
                        <button
                            type="button"
                            className={
                            activeTab === "description"
                                ? "product-tabs__tab active"
                                : "product-tabs__tab"
                            }
                            onClick={() => setActiveTab("description")}>
                            <div className="text text_md"> Description </div>
                        </button>

                        <button
                            type="button"
                            className={
                            activeTab === "details"
                                ? "product-tabs__tab active"
                                : "product-tabs__tab"
                            }onClick={() => setActiveTab("details")}>

                            <div className="text text_md"> Détails du produit </div>
                        </button>
                    </div>

                    <div className="product-tabs__content">
                        {activeTab === "description" && (
                            <div className="product-tabs__panel text text_sm">
                                {renderProductText(product.description)}
                            </div>
                        )}

                    {activeTab === "details" && (
                        <div className="product-tabs__panel text text_sm">
                            {renderProductText(product.details)}
                        </div>
                    )}
                    </div>

                </section>

                <div className="products_list_page_product my_start_12">
                    <div className="flex_between_center header_products">
                        <div className="text text_xl weight_600"> Ajourdiut offers Tech </div>
                        <div className="text text_sm"> Tous </div>                 
                    </div>
                    <div className="products_list">
                        {products?.map((product) => (
                            <div key={product.id}>
                                <ProductCard product={product} />
                            </div>
                        ))}
                    </div>
                </div>
            </div>

        </section>
    );
    /* --------------------------------------------------------------------------------------------------- */


}
