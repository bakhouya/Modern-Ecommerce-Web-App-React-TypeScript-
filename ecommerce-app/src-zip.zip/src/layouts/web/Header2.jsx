

import { useState } from "react";
import { Link } from 'react-router-dom';
import { useSettings } from '../../context/settings/PublicSettingsContext';
import { Search } from "lucide-react";
const categories = ["Enchères judiciaires", "Supermarché", "Aides nationales", "Centre de coupons"];
import CategoryMenu from "../../widgets/web/categories/CategoryMenu"
import CartModal from "../../widgets/web/header/CartMiniModal"
import AccountMenu from "../../widgets/web/header/AccountMenu"
import MobileBottomNav from "./MobileBottomNav"
import { usePublicCategoryParents } from "../../controllers/useCategory"
import { useCart } from "../../controllers/useCart"
import cartIcon from "../../assets/svg/cart.svg"
import favorite from "../../assets/svg/favorite.svg"
import WEBROUTES from "../../routers/web/path";

function Header() {
    const [isCartOpen, setIsCartOpen]   = useState(false);

    const {data: categoriesParents }    = usePublicCategoryParents();
    const {data: cart }                 = useCart();
    const { settingsQuery }             = useSettings();
    const settings                      = settingsQuery.data ;



    return (
        <>
        <header className="store-header">

            <div className="announcement web_container">
                <div className="announcement__content">
                    <span className="text text_xs ">Free shipping on orders over $75</span>
                    <span className="announcement__separator">•</span>
                    <span className="text text_xs ">30-day easy returns</span>
                    <span className="announcement__separator">•</span>
                    <span className="text text_xs ">Track Order</span>
                </div>
            </div>

            <div className="header-main">
                <div className="header-main__inner web_container">

                    <Link to={WEBROUTES.HOME} className="logo">
                        <img src={settings?.logo} alt="" className='logo_header' loading="lazy"/>
                    </Link>

                    <div className="flex_start_center searchBox__web">
                        <CategoryMenu categories={categoriesParents} screenPhone={false}/>
                        <div className="search">
                            <Search size={19} />
                            <input type="text" placeholder="Search products, brands and more..."/>
                        </div>
                    </div>
                    
                    <div className="header-actions">

                        <AccountMenu />

                        <button className="action">
                            {/* <Heart size={22} className="mx_auto"/> */}
                            <img src={favorite} alt="" width={"20"} loading="lazy" className="mx_auto"/>
                            <div className="text text_sm"> Faviates </div>
                            <span className="badge_actions">2</span>
                        </button>

                        <button className="action" onClick={() => setIsCartOpen(true)}>
                            {/* <ShoppingBag size={22} className="mx_auto"/> */}
                            <img src={cartIcon} alt="" width={"22"} loading="lazy" className="mx_auto"/>
                            <div className="text text_sm weight_600">{cart?.discount ?? "0.00"}{settings?.currency_symbol}</div>
                            <div className="badge_actions">{cart?.items ?? 0}</div>
                        </button>

                        <CartModal isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} cart={cart}/>
                        

                    </div>
                
                </div>
            </div>

            <nav className="navigation">
                <div className="navigation__inner web_container">
                    <div className="flex_between_center">

                        <CategoryMenu categories={categoriesParents}/>

                        <div className="navigation__links">
                            {categories.map((category, index) => (  
                            // <Link to={"#"} key={category} className={`link_menu ${index === 0 ? "active" : ""}`}>
                            <Link to={"#"} key={category} className={`link_menu`}>
                                <div className="text text_sm">  {category}   </div>
                                {/* {index === 0 && ( <span className="new-label">NEW</span>)} */}
                            </Link>
                            ))}
                        </div>

                    </div>
                    <Link to={"#"} className="links_offers">
                        <div className="text text_sm white"> Offers partie de 50% </div>
                    </Link> 

                </div>
            </nav>

        </header>


        <MobileBottomNav categories={categoriesParents} cart={cart}/>
        </>
    );

}


export default Header;