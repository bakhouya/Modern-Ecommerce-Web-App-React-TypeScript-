import {
    Home,
    Search,
    ShoppingCart,
    User,
    Menu,
} from "lucide-react";
import { NavLink } from "react-router-dom";
import WEBROUTES from "../../routers/web/path";
import CategoryMenu from "../../widgets/web/categories/CategoryMenu";
import type { CategoryTypesParents } from "../../types/categoryTypes";
import { useState } from "react";
import type { Cart } from "../../types/cartTypes";
import CartModal from "../../widgets/web/header/CartMiniModal";

interface CategoryMenuProps {
    categories: CategoryTypesParents[];
    cart: Cart | null;
}

const MobileBottomNav = ({ categories, cart }: CategoryMenuProps) => {
    const [isCartOpen, setIsCartOpen]   = useState(false);
    return (
        <>
        <nav className="mobile-bottom-nav">
            <div className="mobile-bottom-nav__inner">

                {/* <button type="button" className="mobile-bottom-nav__item">
                    <Menu size={21} />
                    <span>Menu</span>
                </button> */}
                <CategoryMenu categories={categories} screenPhone={true}/>

                <NavLink to="/search" className="mobile-bottom-nav__item">
                    <Search size={21} />
                    <span>Recherche</span>
                </NavLink>

                <NavLink to={WEBROUTES.HOME} className="mobile-bottom-nav__item">
                    <Home size={23} />
                    <span>Accueil</span>
                </NavLink>

                <button type="button" className="mobile-bottom-nav__item" onClick={() => setIsCartOpen(true)}>
                    <div className="mobile-bottom-nav__cart-icon">
                        <ShoppingCart size={21} />
                        <span className="mobile-bottom-nav__badge">0</span>
                    </div>
                    <span>Panier</span>
                </button>
                

                <NavLink to="/account" className="mobile-bottom-nav__item">
                    <User size={21} />
                    <span>Compte</span>
                </NavLink>

            </div>
            
        </nav>

        <CartModal isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} cart={cart}/>
        </>
    );
};

export default MobileBottomNav;