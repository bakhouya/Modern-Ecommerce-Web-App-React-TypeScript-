const WEBROUTES = {
    HOME        : "/v1/",
    TRACKORDER  : "/v1/orders/track-order/",
    CHECKOUT    : "/v1/cart/checkout/",
    CATEGORY    : (catID: string) => `/v1/categories/products/${catID}/ghjlklmgjhfj/fjhgjhkkgj/ukgkjgj/`,
    PRODUCT     : (id: string) => `/v1/products/${id}`,
  
};

export default WEBROUTES;