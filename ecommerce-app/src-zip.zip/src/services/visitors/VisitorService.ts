


import type { TrackVisitorResponse } from '../../types/visitorsTypes';
import type { VisitorFilterTypes, VisitorsResponseTypes } from '../../types/visitorTypes';
import api from '../axiosInstance';

const BASE_URL = '/panel/visitors/';  

export const VisitorService = {
    async getAll(params?: VisitorFilterTypes): Promise<VisitorsResponseTypes> {
        const response = await api.get<VisitorsResponseTypes>(BASE_URL, { params });
        return response.data ;
    },
};


export const TrackvisitorService = {
  track: async (): Promise<TrackVisitorResponse> => {
    const response = await api.get<TrackVisitorResponse>("/public/track/");

    return response.data;
  },
};
