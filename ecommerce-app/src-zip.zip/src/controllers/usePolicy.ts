
/* ---------------------------------------------------------------------------------*/
/* ---------------------------------------------------------------------------------*/
import { createCrudHooks } from './CrudController';
import type { TFunction } from 'i18next';
import type { PolicyApiPaginatedResponse, PolicyFormData, PolicyParamsFilterTypes, PolicyTypes } from '../types/policyTypes';
import { policyService } from '../services/settings/policyService';
/* ---------------------------------------------------------------------------------*/


/* ---------------------------------------------------------------------------------*/
/* ---------------------------------------------------------------------------------*/
export const createPolicyHooks = (t: TFunction) => {
  return createCrudHooks<PolicyApiPaginatedResponse<PolicyTypes>, PolicyFormData, PolicyParamsFilterTypes >({
    service: policyService,
    queryKey: 'policies',
    t,
  });
};
/* ---------------------------------------------------------------------------------*/


